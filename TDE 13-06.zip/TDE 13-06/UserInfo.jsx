import {useState} from 'react';

const UserInfo = ({ name, birthday, email }) => {
  return (
    <div>
      <p>Nome: {name}</p>
      <p>Data de nascimento: {birthday}</p>
      <p>e-mail: {email}</p>
    </div>
  );
};

const UserList = ({ users }) => {
  return (
    <div>
      {users.map((user, index) => (
        <UserInfo
          key={index}
          name={user.name}
          birthday={user.birthday}
          email={user.email}
        />
      ))}
    </div>
  );
};

const App = () => {
  const users = [
    {
      name: 'Teste nome',
      birthday: '10/10/10',
      email: 'teste@teste.com'
    },
    {
      name: 'Teste nome 2',
      birthday: '10/10/10',
      email: 'teste2@teste.com'
    },
    {
      name: 'Teste nome 3',
      birthday: '10/10/10',
      email: 'teste3@teste.com'
    }
  ];

  return (
    <div>
      <UserList users={users} />
    </div>
  );
};
 export default App
